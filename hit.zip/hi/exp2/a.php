<html>
<body>
<?php
$flower_shop = array ("rose", "daisy","orchid");echo "Flowers: 
".$flower_shop[0].",".$flower_shop[1].", ".$flower_shop[2]."";
?>
</body>
</html>

