<html>
<body>
<?php
// Function definition
function myFunction()
{
echo "Hello world";
}
// Function call
myFunction();
?>
</body>
</html>
