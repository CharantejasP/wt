<html>
<body>
<?php
$flower_shop = array ( "rose" => "5.00", "daisy" => "4.00", "orchid" 
 => "2.00" );
// Display the array values
 echo "rose costs" .$flower_shop['rose'].",daisy costs 
".$flower_shop['daisy'].",and orchild
costs ".$flower_shop['orchid']."";
?>
</body>
</html>