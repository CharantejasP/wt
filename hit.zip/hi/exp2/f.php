<html>
<body>
<?php
$num1=10;
$num2=20;
echo "Numbers before swapping:<br/>";
echo "Num1=".$num1;
echo "<br/>Num2=".$num2;
// Function call
swap($num1,$num2);
// Function definition
function swap($n1,$n2)
{
$temp=$n1;
$n1=$n2;
$n2=$temp;
echo "<br/><br/>Numbers after
swapping:<br/>";
echo "Num1=".$n1;
echo "<br/>Num2=".$n2;
}
?>
</body>
</html>