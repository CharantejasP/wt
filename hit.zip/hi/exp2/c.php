<html>
<body>
<?php
$flower_shop=array("rose"=>"5.00", 
"daisy"=>"4.00","orchid"=>"2.00");
foreach($flower_shop as $x=>$x_value) {
echo "Flower=" . $x . ", Value=" . $x_value;
echo "<br>";
}
?>
</body>
</html>
