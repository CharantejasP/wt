<html>
<body>
<?php
// Function definition
function writeName($fname)
{
echo $fname . " Refsnes.<br />";
}
echo "My name is ";
writeName("Kai Jim"); //Function call
echo "My sister's name is ";
writeName("Hege"); // Function call
echo "My brother's name is ";
writeName("Stale"); // Function call
?>
</body>
</html>
