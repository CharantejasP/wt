import java.io.*;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StudentSearch extends HttpServlet {
    private Connection cn; // Declare Connection as an instance variable

    public void init() {
        try {
            // Initialize the Connection in the init() method
            Class.forName("com.mysql.cj.jdbc.Driver");
            cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/crud", "root", "");
        } catch (Exception ce) {
            System.out.println("Error: " + ce.getMessage());
        }
    }

    public void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter pw = resp.getWriter();
        try {
            int rno = Integer.parseInt(req.getParameter("t1"));
            String qry = "select * from student where RollNo=" + rno;
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(qry);
            pw.print("Students Detail");
            pw.print("<table border=1>");
            while (rs.next()) {
                pw.print("<tr>");
                pw.print("<td>" + rs.getInt(1) + "</td>");
                pw.print("<td>" + rs.getString(2) + "</td>");
                pw.print("<td>" + rs.getString(3) + "</td>");
                pw.print("<td>" + rs.getString(4) + "</td>");
                pw.print("<td>" + rs.getString(5) + "</td>");
                pw.print("</tr>");
            }
            pw.print("</table>");
        } catch (Exception se) {
            se.printStackTrace(); // Print the exception for debugging
        }
        pw.close();
    }
}
