<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
</head>
<body>
    <h2>Login</h2>
    <form method="post" action="login1.php">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>
        <input type="submit" value="Login">
    </form>
    <?php
session_start();

// Replace these with your actual username and password
$valid_username = "vinay";
$valid_password = "1234";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $entered_username = $_POST["username"];
    $entered_password = $_POST["password"];

    if ($entered_username == $valid_username && $entered_password == $valid_password) {
        // Successful login
        $_SESSION["username"] = $entered_username;
        header("Location: welcome.php");
    } else {
        // Invalid credentials
        echo "Invalid username or password. <a href='login1.php'>Try again</a>";
    }
}
?>
</body>
</html>
