<?php
$con=new MongoDB\Driver\Manager("mongodb://localhost:27017");
$query=new MongoDb\Driver\BulkWrite;
$query->insert(["name"=>"Sai","Age"=>45,"city"=>"hyd"]);
$con->executeBulkWrite("Hotels.Names",$query);
?>