var mongodb = require('mongodb');
var MongoClient = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/';

MongoClient.connect(url, function (error, client) {
  if (error) {
    throw error;
  }

  var db = client.db('navigcollection');

  var collectionName = 'pract';

  var pract = [
    { _id: 11, name: 'Chaman Gautam', address: 'Harvansh Nagar Ghaziabad', orderdata: 'Jeans' },
    { _id: 12, name: 'Shivani', address: 'Harvansh Nagar Ghaziabad', orderdata: 'Jeans' },
    { _id: 13, name: 'Menu', address: 'Harvansh Nagar Ghaziabad', orderdata: 'Top' },
    { _id: 14, name: 'Brajbala', address: 'Harvansh Nagar Ghaziabad', orderdata: 'Dining table' },
    { _id: 15, name: 'Ramsaran', address: 'Harvansh Nagar Ghaziabad', orderdata: 'Washing machine' },
    { _id: 16, name: 'Dheeraj', address: 'Harvansh Nagar Ghaziabad', orderdata: 'Jeans' }
  ];

  db.collection(collectionName).insertMany(pract, function (error, response) {
    if (error) {
      throw error;
    }
    console.log('Number of documents inserted: ' + response.insertedCount);
    client.close();
  });
});
