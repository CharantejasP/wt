// const fs=require('fs');
// var data=fs.readFileSync("abc.txt").toString();
// console.log(data);

// const fs=require("fs");
// fs.writeFile("abc.txt","/nhow are you?",(err)=>{
//     if(err){
//         console.log(err);
//     }
// });



// const fs=require("fs");
// fs.appendFile("abc.txt","My name is vinAy!!!",(err)=>{
//     if(err){
//         console.log(err);
//     }
// })

const fs=require('fs');
 fs.unlinkSync('abc.txt');
