const app=require("express")();
const http=require('http').Server(app)
const mongoose=require('mongoose');
mongoose.connect("mongodb+srv://charanteja5c4:Rbuf8tX4y3lMCJSN@test-pro-db.i1vzouy.mongodb.net/?retryWrites=true&w=majority")
const User=require('./models/userModel')
async function insert(){
    await User.create({
        name:"ali",
        email:"ali@gmail.com"
    })
}
insert()
//connect to database
http.listen(3000,function(){
    console.log("server is running at port 3000");
})

// const app = require("express")();
// const http = require('http').Server(app);
// const mongoose = require('mongoose');
// mongoose.connect("mongodb+srv://charanteja5c4:Rbuf8tX4y3lMCJSN@test-pro-db.i1vzouy.mongodb.net/?retryWrites=true&w=majority");
// const User = require('./models/userModel');

// // Define an array of objects with the data you want to insert
// const usersToInsert = [
//     {
//         name: "ali",
//         email: "ali@gmail.com"
//     },
//     {
//         name: "john",
//         email: "john@gmail.com"
//     },
//     {
//         name: "mary",
//         email: "mary@gmail.com"
//     }
// ];

// async function insert() {
//     // Use insertMany to insert multiple rows at once
//     await User.insertMany(usersToInsert);

//     console.log("Inserted", usersToInsert.length, "users into the database.");
// }

// insert();

// // Connect to the database
// http.listen(3000, function () {
//     console.log("Server is running at port 3000");
// });

// const app = require("express")();
// const http = require('http').Server(app);
// const mongoose = require('mongoose');
// mongoose.connect("mongodb+srv://charanteja5c4:Rbuf8tX4y3lMCJSN@test-pro-db.i1vzouy.mongodb.net/?retryWrites=true&w=majority");
// const User = require('./models/userModel');

// async function updateUserName() {
//     // Update the user with the name "ali" to "charan"
//     await User.updateOne({ name: "ali" }, { name: "charan" });

//     console.log("Updated the user's name to 'charan'.");
// }

// updateUserName();

// // Connect to the database
// http.listen(3000, function () {
//     console.log("Server is running at port 3000");
// });

// const app = require("express")();
// const http = require('http').Server(app);
// const mongoose = require('mongoose');
// mongoose.connect("mongodb+srv://charanteja5c4:Rbuf8tX4y3lMCJSN@test-pro-db.i1vzouy.mongodb.net/?retryWrites=true&w=majority");
// const User = require('./models/userModel');

// async function deleteCharanUser() {
//     // Delete the user with the name "charan"
//     await User.deleteOne({ name: "charan" });

//     console.log("Deleted the user with the name 'charan'.");
// }

// deleteCharanUser();

// // Connect to the database
// http.listen(3000, function () {
//     console.log("Server is running at port 3000");
// });

